# 8–12 Week Timeline & Light Budget

Weeks 1–2: Site onboarding, rater calibration (1–2 hrs), baseline artifact collection
Weeks 3–6: Four Spiral sessions (45–90 min) + surveys
Week 7: Scoring (2 raters x ~3 min/artifact)
Week 8: Analysis & brief
Optional 9–12: Write-up & submission

Budget (per site, ballpark):
- Facilitator time: 6–8 hours
- Raters: 3–5 hours
- Coordination: 2 hours
- Optional stipend/incentives as per local policy
