# Adult Participant Survey (Likert 1–5)

1) Today's session improved my understanding of the problem's *causes*.
2) I considered *ethical impacts* more than usual.
3) The activity helped me imagine *alternative designs/solutions*.
4) I became aware of *assumptions/blind spots*.
5) Overall, the session improved *clarity* of next steps/questions.

Open: What question will you carry forward?
