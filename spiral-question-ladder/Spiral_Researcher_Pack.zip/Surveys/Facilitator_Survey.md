# Facilitator Survey (Post-Session)

- Time per layer (min): C__, Ca__, E__, T__, M__
- What worked well?
- Where did the spiral stall?
- Any safety/ethics concerns raised?
- What will you change next time?
