# Student Survey (Likert 1–5)

1) I understood key terms better (Clarifying).
2) I can explain why things happen (Causal).
3) I thought about fairness/impact (Ethical).
4) I imagined ways to redesign/improve (Transformational).
5) I noticed assumptions or missing voices (Meta).

Open: What did you realize or change in your thinking?
