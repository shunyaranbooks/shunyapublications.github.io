# Call For Partners (Web/LinkedIn copy)

We’re inviting schools, universities, and organizations to pilot the **Spiral Question Ladder**—a 5-layer inquiry scaffold (Clarify→Causal→Ethical→Transformational→Meta). We supply templates, rubrics, and simple data capture; you run 4 sessions in 4 weeks. Minimal risk, high learning value. Results shared back to you. License: CC BY-SA.

Contact: [email]  |  Pack: provided to participating sites.
