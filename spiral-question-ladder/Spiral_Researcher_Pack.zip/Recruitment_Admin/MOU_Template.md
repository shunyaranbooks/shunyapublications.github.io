# Memorandum of Understanding (Template)

Parties: Research team <> Partner site
Scope: 4-week evaluation of Spiral Question Ladder
Data: De-identified artifacts + short surveys
IP/License: CC BY-SA for templates; partner owns raw site data; shared publication rights with mutual review
Privacy: No PII collected; storage on encrypted drives
Timeline: Start date ___; end date ___
Signatures: ____________________
