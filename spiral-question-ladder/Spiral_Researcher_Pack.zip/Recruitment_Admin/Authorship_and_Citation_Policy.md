# Authorship & Citation Policy

- Follow ICMJE-style contributorship.
- Offer co-authorship to site leads if they contribute to study design/interpretation.
- Cite the Spiral framework and include link to the pack.
- Share preprints and data dictionaries openly where possible.
