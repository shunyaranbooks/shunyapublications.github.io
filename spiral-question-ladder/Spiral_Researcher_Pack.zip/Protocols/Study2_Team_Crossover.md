# Study 2 — Team Crossover (Meetings) — 4 sessions

## Design
Two teams (A,B). Weeks 1–2: A=BAU meetings; B=Spiral Meetings. Weeks 3–4: switch.

## Procedure
- Each session uses one provocation; produce a spiral map and a carry-forward question.
- Collect participant survey after each meeting (clarity, framing, perceived depth).

## Outcomes
- Primary: Spiral Rubric on meeting artifacts (Recursion, Generativity, Friction, Layering, Meta-Index).
- Secondary: Decision quality proxy (clarity of next steps; fewer rework loops).

## Analysis
- Within-team comparisons across phases; mixed-effects model optional.
