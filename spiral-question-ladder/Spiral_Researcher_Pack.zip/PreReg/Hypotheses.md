# Hypotheses (Editable)

H1: Spiral sessions will score higher on the Spiral Rubric (total) than BAU artifacts.
H2: Spiral groups will show higher systems/causal reasoning post-tests.
H3: Spiral sessions will yield more Ethical and Meta-layer questions per 30 minutes.
H4: Facilitators will report higher perceived clarity/next-steps after Spiral Meetings.
