# Parent/Guardian Permission + Minor Assent

Purpose, procedures, risks/benefits, confidentiality as above in age-appropriate language.
Parent/Guardian Signature: __________  Date: ___
Student Assent: I agree to take part.  Signature: __________  Date: ___
