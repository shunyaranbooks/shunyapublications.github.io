# Adult Consent Template (Minimal Risk)

Purpose: Evaluate the Spiral Question Ladder in practice settings.
Procedures: You may be asked to participate in a 45–90 minute session and complete short surveys. Sessions may produce anonymous artifacts (spiral maps).
Risks/Benefits: Minimal risk. Potential benefit is improved inquiry.
Confidentiality: No names in artifacts; coded IDs only.
Voluntary: Participation is voluntary; you may withdraw anytime.
Contact: [Researcher email/phone].
Signature: ____________________   Date: ____________
